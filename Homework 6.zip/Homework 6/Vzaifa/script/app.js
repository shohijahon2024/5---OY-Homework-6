const todoList = JSON.parse(localStorage.getItem('todos')) || [];
const ulElement = document.getElementById('todoList');

function renderTodos() {
    ulElement.innerHTML = '';
    todoList.forEach((todo, index) => {
        const li = document.createElement('li');
        li.textContent = `${todo.name} - ${todo.time}`;
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'O\'chirish';
        deleteButton.onclick = () => deleteTodo(index);
        li.appendChild(deleteButton);
        ulElement.appendChild(li);
    });
}

function addTodo() {
    const inputElement = document.getElementById('todoInput');
    const todoName = inputElement.value.trim();
    if (todoName) {
        const now = new Date();
        const timeStr = `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`;
        const newTodo = {
            name: todoName,
            time: timeStr
        };
        todoList.push(newTodo);
        localStorage.setItem('todos', JSON.stringify(todoList));
        inputElement.value = '';
        renderTodos();
    }
}

function deleteTodo(index) {
    todoList.splice(index, 1);
    localStorage.setItem('todos', JSON.stringify(todoList));
    renderTodos();
}

document.getElementById('addTodo').addEventListener('click', addTodo);
renderTodos();


